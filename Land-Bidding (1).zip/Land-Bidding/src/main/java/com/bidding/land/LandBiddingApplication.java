package com.bidding.land;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LandBiddingApplication {

	public static void main(String[] args) {
		SpringApplication.run(LandBiddingApplication.class, args);
	}

}

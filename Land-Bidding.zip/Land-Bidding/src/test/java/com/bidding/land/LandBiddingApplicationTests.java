package com.bidding.land;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandBiddingApplicationTests {

	@Test
	void contextLoads() {
	}

}
